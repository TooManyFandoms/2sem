#ifndef __TRANSFORM_H__
#define __TRANSFORM_H__

#include "tree.h"

void tree_transform(Tree *t);

int check_reverse(Tree t);

int check_right(Tree t);

#endif
